import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CalendarController } from './calendar.controller';
import { CalendarService } from './calendar.service';
import { EconomicEvent } from './entities/economic-event.entity';

@Module({
  imports: [
    HttpModule,
    TypeOrmModule.forFeature([EconomicEvent]),
  ],
  controllers: [CalendarController],
  providers: [CalendarService],
})
export class CalendarModule {}