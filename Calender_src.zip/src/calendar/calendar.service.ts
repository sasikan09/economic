import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EconomicEvent } from './entities/economic-event.entity';

@Injectable()
export class CalendarService implements OnModuleInit {
  private readonly logger = new Logger(CalendarService.name);

  constructor(
    @InjectRepository(EconomicEvent)
    private readonly eventRepository: Repository<EconomicEvent>,
  ) {}

  async onModuleInit() {
    await this.fetchAndSyncExternalEvents();
  }

  async fetchAndSyncExternalEvents(): Promise<void> {
    try {
      const count = await this.eventRepository.count();
      if (count === 0) {
        const mockEvents = [
          {
            event_name: 'Federal Reserve Interest Rate Decision',
            country: 'USD',
            impact: 'HIGH',
            actual: '5.25%',
            forecast: '5.25%',
            previous: '5.50%',
            date_time: new Date().toISOString(),
          },
          {
            event_name: 'US Consumer Price Index (CPI) YoY',
            country: 'USD',
            impact: 'HIGH',
            actual: '3.1%',
            forecast: '2.9%',
            previous: '3.4%',
            date_time: new Date(Date.now() + 86400000).toISOString(),
          },
          {
            event_name: 'Non-Farm Payrolls',
            country: 'USD',
            impact: 'HIGH',
            actual: '180K',
            forecast: '170K',
            previous: '216K',
            date_time: new Date(Date.now() + 172800000).toISOString(),
          },
        ];

        for (const item of mockEvents) {
          const newEvent = this.eventRepository.create(item);
          await this.eventRepository.save(newEvent);
        }
        this.logger.log('สร้างข้อมูลตัวอย่างปฏิทินเศรษฐกิจเรียบร้อยแล้ว');
      }
    } catch (error) {
      this.logger.error('เกิดข้อผิดพลาดในการสร้างข้อมูล', error);
    }
  }

  async findAll(): Promise<EconomicEvent[]> {
    return this.eventRepository.find({ order: { date_time: 'ASC' } });
  }
}